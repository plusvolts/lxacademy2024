package com.lx.mapapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapappApplicationTests {

	@Test
	void contextLoads() {
	}

}
