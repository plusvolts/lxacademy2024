package com.example.mapappmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        WebView mWebView = (WebView)findViewById(R.id.wv_map);

        WebSettings mWebSettings = mWebView.getSettings(); // 웹뷰에서 webSettings를 사용할 수 있도록 함.
        mWebSettings.setJavaScriptEnabled(true);           //웹뷰에서 javascript를 사용하도록 설정

        mWebView.loadUrl("http://172.30.1.55:8080/mapapp/");
    }
    public void onBackButtonClicked(View view){
        finish();
    }
}